/*
 * File:   ArbolBB.h
 * Author: ANA RONCAL
 *
 * Created on 13 de noviembre de 2024, 13:48
 */

#ifndef ARBOLBB_H
#define ARBOLBB_H

#include "ArbolB.h"
struct ArbolBinarioBusqueda{
    struct ArbolBinario arbolBinario;
};

#endif /* ARBOLBB_H */