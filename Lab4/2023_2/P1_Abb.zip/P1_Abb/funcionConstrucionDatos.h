/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionConstrucionDatos.h
 * Author: andre
 *
 * Created on 6 de diciembre de 2024, 04:07 PM
 */

#ifndef FUNCIONCONSTRUCIONDATOS_H
#define FUNCIONCONSTRUCIONDATOS_H
void generarArbolSistema(struct ArbolBinario & arbolSistema);
#endif /* FUNCIONCONSTRUCIONDATOS_H */
