/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabras.h
 * Author: andre
 *
 * Created on 28 de noviembre de 2024, 08:52 PM
 */

#ifndef PALABRAS_H
#define PALABRAS_H

struct Palabras{
    char palabra[100];
};

#endif /* PALABRAS_H */

